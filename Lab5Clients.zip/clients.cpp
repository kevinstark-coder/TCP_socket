
#define _CRT_SECURE_NO_WARNINGS
#include <SFML/Network.hpp>
#include <iostream>
#include <string>
#include <thread>
#include <stdio.h>
#include <stdlib.h>
#include <chrono>
#include <atomic>

std::atomic<bool> isRunning(true);
struct tcpMessage {
    unsigned char nVersion ;
    unsigned char nType ;
    unsigned short nMsgLen;
    std::string chMsg;
};

sf::TcpSocket socket;
void handlereceive() {
    while (isRunning)
    {
        sf::Packet packet;
        tcpMessage msg1;
        if (socket.receive(packet) == sf::Socket::Done) 
        {
            packet >> msg1.nVersion >> msg1.nType >> msg1.nMsgLen;
            packet >> msg1.chMsg;
            std::cout << "Received Msg Type: " << static_cast<int>(msg1.nType) << "; Msg: " << msg1.chMsg << std::endl;
        }
    }
}



int main(int argc, char* argv[]) {
    if (argc != 3) {
        std::cerr << "Usage: " << argv[0] << " <IP> <port>" << std::endl;
        return 1;
    }

    sf::IpAddress serverIp(argv[1]);
    unsigned short port = static_cast<unsigned short>(std::stoi(argv[2]));

    
    
    if (socket.connect(serverIp, port) != sf::Socket::Done) {
        std::cerr << "Could not connect to server" << std::endl;
        return 1;
    }
    socket.setBlocking(false);
    
    std::thread inputThread(handlereceive);
    sf::Packet packet;
    tcpMessage msg;
    while (true) {
        packet.clear();
        std::cout << "Please enter command: ";
        std::string command;
        std::getline(std::cin, command);

        if (command == "q") {
            isRunning = false;
            break;
        }
        if (command[0] == 'v') {
            msg.nVersion = static_cast<unsigned char>(std::stoi(command.substr(2)));
            //printf("version %c\n", msg.nVersion);
        }
        else if (command[0] == 't') {
            size_t pos = command.find(' ', 2);
            msg.nType = static_cast<unsigned char>(std::stoi(command.substr(2, pos - 2)));
            std::string message = command.substr(pos + 1);
            msg.chMsg = message;
            msg.nMsgLen = static_cast<unsigned short>(message.size());
            packet << msg.nVersion << msg.nType << msg.nMsgLen<<msg.chMsg;
            std::size_t packetSize;
            socket.send(packet);
            //printf("version %c\n", msg.nVersion);
            //printf("type %c\n", msg.nType);
            //printf("length %d\n", msg.nMsgLen);
            //std::cout << message << std::endl;
            //packetSize = packet.getDataSize();
            //std::cout << "Size of packet to be sent: " << packetSize << " bytes." << std::endl;
        }



        std::this_thread::sleep_for(std::chrono::milliseconds(1000)); // Avoid busy waiting

    }
    inputThread.join();
    socket.disconnect();
    return 0;
}