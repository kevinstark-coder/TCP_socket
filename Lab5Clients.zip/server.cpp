#include <SFML/Network.hpp>
#include <iostream>
#include <list>
#include <string>
#include <algorithm>
#include <mutex>
#include <thread>
#include <atomic>

struct tcpMessage {
    unsigned char nVersion;
    unsigned char nType ;
    unsigned short nMsgLen;
    std::string chMsg;
};

std::list<sf::TcpSocket*> clients;
sf::SocketSelector selector;
tcpMessage lastMessage;
std::mutex messageMutex;
std::mutex clientsMutex;
std::atomic<bool> isRunning(true);

void processClientMessage(sf::TcpSocket& client, std::list<sf::TcpSocket*>* clientsa) {
    sf::Packet packet;
    packet.clear();
    if (client.receive(packet) == sf::Socket::Done) {
        //std::size_t packetSize = packet.getDataSize();
        //std::cout << "Size of packet to be sent: " << packetSize << " bytes." << std::endl;
        tcpMessage msg;

        packet >> msg.nVersion >> msg.nType >> msg.nMsgLen>>msg.chMsg;
        //packetSize = packet.getDataSize();
        //std::cout << "Size of packet to be sent: " << packetSize << " bytes." << std::endl;

            //msg.chMsg[msg.nMsgLen] = '\0';  // Ensure null-termination
            //printf("version %c\n", msg.nVersion);
            //printf("type %c\n", msg.nType);
            //printf("length %d\n", msg.nMsgLen);
            //std::cout << msg.chMsg << std::endl;
            

            messageMutex.lock();
            lastMessage = msg;
            messageMutex.unlock();

            if (msg.nVersion == 102)
            {           
                if (msg.nType == 77) 
                {
                    /*printf("77 \n");*/
                    for (auto it = clientsa->begin(); it != clientsa->end(); ++it) {
                        if (*it != &client)
                            (*it)->send(packet);
                    }
                }      
                if (msg.nType == 201) 
                {
                    /*printf("201 \n");*/
                    std::reverse(msg.chMsg.begin(), msg.chMsg.end());
                    sf::Packet responsePacket;
                    responsePacket << msg.nVersion << msg.nType << msg.nMsgLen<<msg.chMsg;
                    client.send(responsePacket);
                }
            }
        

    }

}

void handleInput() {
    std::string command;
    while (true) {
        std::cout << "Please enter command: ";
        std::getline(std::cin, command);

        if (command == "msg") {
            messageMutex.lock();
            std::cout << "Last Message: " << lastMessage.chMsg << std::endl;
            messageMutex.unlock();
        }
        else if (command == "clients") {
            clientsMutex.lock();
            std::cout << "Number of Clients: " << clients.size() << std::endl;
            for (auto& client : clients) {
                sf::IpAddress ip = client->getRemoteAddress();
                unsigned short port = client->getRemotePort();
                std::cout << "IP Address: " << ip << " | Port: " << port << std::endl;
            }
            clientsMutex.unlock();
        }
        else if (command == "exit") {
            isRunning = false;
            break;
        }
    }
}

int main(int argc, char* argv[]) {
    if (argc != 2) {
        std::cerr << "Usage: " << argv[0] << " <port>" << std::endl;
        return 1;
    }

    unsigned short port = static_cast<unsigned short>(std::stoi(argv[1]));

    sf::TcpListener listener;
    if (listener.listen(port) != sf::Socket::Done) {
        std::cerr << "Could not listen on port " << port << std::endl;
        return 1;
    }
    listener.setBlocking(false);
    selector.add(listener);

    std::thread inputThread(handleInput);

    while (isRunning) {
        if (selector.wait(sf::milliseconds(100))) {
            if (selector.isReady(listener)) {
                sf::TcpSocket* client = new sf::TcpSocket;
                if (listener.accept(*client) == sf::Socket::Done) {
                    client->setBlocking(false);
                    clients.push_back(client);
                    selector.add(*client);
                }
                else {
                    delete client;
                }
            }
            else {
                for (auto it = clients.begin(); it != clients.end(); ++it) {
                    sf::TcpSocket& client = **it;
                    if (selector.isReady(client)) {
                        processClientMessage(client, &clients);
                    }
                }
            }
        }
    }
        
    inputThread.join();

    for (auto& client : clients) 
    {
        selector.remove(*client);
        client->disconnect();
        delete client;
    }

    return 0;
}